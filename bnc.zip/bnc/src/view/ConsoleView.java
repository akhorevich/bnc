package view;

import controller.GameController;

public class ConsoleView {
    GameController gCont;
    boolean guessed;
    public void checkGame(int bulls, int cows, int guesses){
       gCont = new GameController();

        guessed = gCont.isGuessed();



        if (bulls == 4) {
            guessed = true;
        } else if (guesses == 10 && !guessed) {
            System.out.println("Вы проиграли! Задуманное противником число было " + gCont.getEnemyNum());
        } else {
            System.out.println(guesses + ". " + cows + " Коровы и " + bulls + " Быка.");
            System.out.println();
            gCont.setNumber();
        }
    }



}

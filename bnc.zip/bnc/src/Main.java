import controller.GameController;
import view.ConsoleView;

public class Main {
    public static void main(String[] args) {
        GameController gameController = new GameController();
        gameController.Game();
    }
}

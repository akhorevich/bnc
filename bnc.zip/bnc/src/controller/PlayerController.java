package controller;

import model.Player;

public class PlayerController {
private Player player;

    public PlayerController(Player player) {
        this.player = player;
    }

    public int getPlayerNumber(){
        return player.getNumber();
    }

    public void setPlayerNumber(final int PlayerNumber){
        player.setNumber(PlayerNumber);
    }
}

package controller;

import model.Player;
import view.ConsoleView;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class GameController {
    private final static Scanner IN = new Scanner(System.in);
    int enemyNum = 0;
    int number = 0;
    int bulls;
    int cows;
    boolean guessed = false;
    int guesses = 0;
    Player player = new Player();
    PlayerController pCont = new PlayerController(player);
    ConsoleView view = new ConsoleView();


    public void Game() {

        enemyNumber();
        System.out.println(getEnemyNum());
        setNumber();



        do {
            bulls = 0;
            cows = 0;
            guesses++;
            String numberStr = pCont.getPlayerNumber() + "";
            String enemyNumberStr = getEnemyNum() + "";
            for (int i = 0; i < 4; i++) {


                if (numberStr.charAt(i) == enemyNumberStr.charAt(i)) {
                    bulls++;
                    view.checkGame(bulls,cows,guesses);

                } else if (enemyNumberStr.contains(numberStr.charAt(i) + "")) {

                    cows++;
                    view.checkGame(bulls,cows,guesses);
                }

            }


        } while (!guessed);
        if (guessed) {
            System.out.println("Вы выиграли, затратив " + guesses + " ходов!");
        }

    }

    public void updateView(){
        view.checkGame(bulls,getCows(),guesses);
    }


    public void enemyNumber() {
        Random r = new Random();
        enemyNum = r.nextInt(9000) + 1000;
        if (checkDupl(enemyNum)) {
            enemyNumber();
        }

    }

    public int getEnemyNum() {
        return enemyNum;
    }

    public void setNumber() {
        try {
            System.out.print("Введите число: ");
            number = IN.nextInt();
            pCont.setPlayerNumber(number);

            if (checkDupl(player.getNumber())) {
                System.out.println("Нельзя вводить повторяющиеся числа!");
                setNumber();
            }

        } catch (final InputMismatchException e) {
            System.out.println("Это не число");

        }
    }

    public static boolean checkDupl(int num) {
        boolean[] digs = new boolean[10];
        while (num > 0) {
            if (digs[num % 10]) return true;
            digs[num % 10] = true;
            num /= 10;
        }
        return false;
    }

    public boolean isGuessed() {
        return guessed;
    }

    public int getBulls() {
        return bulls;
    }

    public void setBulls(int bulls) {
        this.bulls = bulls;
    }

    public int getCows() {
        return cows;
    }

    public void setCows(int cows) {
        this.cows = cows;
    }
}
